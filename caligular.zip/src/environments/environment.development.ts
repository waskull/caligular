export const environment = {
    baseURL : "http://localhost:3000"
};
