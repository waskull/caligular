export const environment = {
    baseURL : "https://nestli.onrender.com"
};
